# OrbMech

OrbMech is a Python package designed for simulating orbital mechanics. It provides tools to calculate orbital parameters, classify orbit types, and visualize orbits using `SimFrame` and `matplotlib`.

## Installation

To install the package, simply run:

pip install orbmech


## Example Usage

```python
from orbmech.core import simulate_orbit, classify_orbit, plot_orbit

# Define initial conditions
initial_conditions = {'semi_major_axis': 1.0, 'eccentricity': 0.1}

# Simulate the orbit
result = simulate_orbit(initial_conditions)

# Classify the orbit type
orbit_type = classify_orbit(result)

# Plot the orbit
plot_orbit(result)

print("Orbit Type:", orbit_type)
